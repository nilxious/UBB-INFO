#include <iostream>
#include <fstream>
#include <cstdlib>
#include <vector>
#include <list>
#include <queue>

void zerorizeaza_matrice(int a[100][100]) {
    for (int i = 0 ; i < 100; i++) {
        for (int j = 0 ; j < 100; j++) {
            a[i][j]=0;
        }
    }
}

void afiseaza_M_adiacenta(int a[100][100], int nodes) {
    std::cout << "\nMatricea de adiacenta:\n";
    for (int i = 1 ; i <= nodes ; i++) {
        for (int j = 1 ; j <= nodes; j++) {
            std::cout<< a[i][j] << " ";
        }
        std::cout << "\n";
    }
}

void construieste_afiseaza_L_incidenta(int M_adiacenta[100][100], std::vector<std::list<int>>& L_incidenta, int nodes) {
    for (int i = 0; i <= nodes; i++) {
        L_incidenta[i].clear();
    }

    // Mergem pe matricea de adiacenta (constrim lista de incidenta)
    for (int i = 1; i <= nodes; i++) {
        for (int j = 1; j <= nodes; j++) {
            if (M_adiacenta[i][j] == 1) {
                // Punem in vector (pe lista i) nodul
                L_incidenta[i].push_back(j);
            }
        }
    }

    std::cout << "\nLista de incidenta:\n";
    for (int i = 1; i <= nodes; i++) {
        std::cout << "Nod " << i << ": ";
        // Display each neighbor in the list of node i
        for (int neighbor : L_incidenta[i]) {
            std::cout << neighbor << " ";
        }
        std::cout << "\n";
    }
}

void construieste_M_adiacenta_din_L_incidenta(std::vector<std::list<int>>& L_incidenta, int M_adiacenta[100][100], int nodes) {
    for (int i = 1; i <= nodes; i++) {
        for (int neighbor : L_incidenta[i]) {
            M_adiacenta[i][neighbor] = 1;
            M_adiacenta[neighbor][i] = 1;
        }
    }
}

void afiseaza_M_incidenta(int M_incidenta[100][100], int nodes, int muchii) {
    std::cout << "\nMatricea de incidenta:\n";
    for (int i = 1; i <= nodes; i++) {
        for (int j = 1; j <= muchii; j++) {
            std::cout << M_incidenta[i][j] << " ";
        }
        std::cout << "\n";
    }
}

void determina_noduri_izolate(int M_adiacenta[100][100], int nodes) {
    std::cout << "\nNoduri izolate:\n";
    bool foundIsolated = false;
    for (int i = 1; i <= nodes; i++) {
        bool isIsolated = true;
        for (int j = 1; j <= nodes; j++) {
            if (M_adiacenta[i][j] == 1) {
                isIsolated = false;
                break;
            }
        }
        if (isIsolated) {
            std::cout << "Nod " << i << " este izolat.\n";
            foundIsolated = true;
        }
    }
    if (!foundIsolated) {
        std::cout << "Nu exista noduri izolate.\n";
    }
}

void verifica_graful_regular(int M_adiacenta[100][100], int nodes) {
    int degree = -1;
    bool isRegular = true;

    for (int i = 1; i <= nodes; i++) {
        int currentDegree = 0;
        for (int j = 1; j <= nodes; j++) {
            if (M_adiacenta[i][j] == 1) {
                currentDegree++;
            }
        }

        if (degree == -1) {
            degree = currentDegree;
        } else if (degree != currentDegree) {
            isRegular = false;
            break;
        }
    }

    if (isRegular) {
        std::cout << "\nGraful este regulat cu gradul " << degree << ".\n";
    } else {
        std::cout << "\nGraful nu este regulat.\n";
    }
}

void determina_matricea_distantelor(int M_adiacenta[100][100], int nodes, int M_dist[100][100]) {
    for (int i = 1; i <= nodes; i++) {
        for (int j = 1; j <= nodes; j++) {
            if (i == j)
                M_dist[i][j] = 0;
            else if (M_adiacenta[i][j] == 1)
                M_dist[i][j] = 1;
            else
                M_dist[i][j] = 99999;
        }
    }

    //Floyd Warshall
    for (int k = 1; k <= nodes; k++) {
        for (int i = 1; i <= nodes; i++) {
            for (int j = 1; j <= nodes; j++) {
                if (M_dist[i][k] != 99999 && M_dist[k][j] != 99999) {
                    M_dist[i][j] = std::min(M_dist[i][j], M_dist[i][k] + M_dist[k][j]);
                }
            }
        }
    }

    std::cout << "\nMatricea distantelor:\n";
    for (int i = 1; i <= nodes; i++) {
        for (int j = 1; j <= nodes; j++) {
            if (M_dist[i][j] == 99999)
                std::cout << "INF ";
            else
                std::cout << M_dist[i][j] << " ";
        }
        std::cout << "\n";
    }
}

void verifica_conexitate(int M_adiacenta[100][100], int nodes) {
    std::vector<bool> vizitat(nodes + 1, false);
    std::queue<int> coada;

    int nod_start = 1;  // Alegem un nod de start
    coada.push(nod_start);
    vizitat[nod_start] = true;
    int numar_noduri_vizitate = 0;

    while (!coada.empty()) {
        int nod_curent = coada.front();
        coada.pop();
        numar_noduri_vizitate++;

        // Verificăm vecinii nodului curent
        for (int i = 1; i <= nodes; i++) {
            if (M_adiacenta[nod_curent][i] == 1 && !vizitat[i]) {
                vizitat[i] = true;
                coada.push(i);
            }
        }
    }

    if (numar_noduri_vizitate == nodes) {
        std::cout << "\nGraful este conex.\n";
    } else {
        std::cout << "\nGraful NU este conex.\n";
    }
}

    int main()
    {
        // PROBLEMA 1
        int M_adiacenta[100][100]; // matricea de adiacenta
        std::vector<std::list<int>> L_incidenta(100); // Lista de incidenta
        int M_incidenta[100][100]; // matricea de incidenta
        int M_dist[100][100]; // matricea distantelor

        int M_adiacenta_convertita[100][100]; // matridce de adiacenta construita din una dintre celelalte 2 reprezentari

        zerorizeaza_matrice(M_adiacenta_convertita);
        zerorizeaza_matrice(M_adiacenta);
        zerorizeaza_matrice(M_incidenta);
        zerorizeaza_matrice(M_dist);


        std::ifstream fisier("in.txt");
        if(!fisier) {
            std::cerr << "Error: nu s-a putut deschide fisierul";
        }

        int nodes;
        fisier >> nodes; // citim numarul de noduri din fisier
        int muchii = 0;


        int x, y; // cele doua noduri
        while (fisier >> x >> y) {
            muchii++;

            // Matricea de adiacenta
            M_adiacenta[x][y] = 1;
            M_adiacenta[y][x] = 1;

            //Matricea de incidenta
            M_incidenta[x][muchii] = 1;
            M_incidenta[y][muchii] = 1;

            //Muchiile
            std::cout << "Muchiile:\n";
            std::cout << "(" << x << ", " << y << ")\n";
        }

        afiseaza_M_adiacenta(M_adiacenta, nodes);

        construieste_afiseaza_L_incidenta(M_adiacenta, L_incidenta, nodes);

        afiseaza_M_incidenta(M_incidenta, nodes, muchii);

        zerorizeaza_matrice(M_adiacenta);
        construieste_M_adiacenta_din_L_incidenta(L_incidenta, M_adiacenta, nodes);
        printf("\n");
        printf("Matricea de adiacenta construita din lista de incidenta:\n");
        afiseaza_M_adiacenta(M_adiacenta,nodes);

        //-------------------------------------------------------------------------

        // PROBLEMA 2
        determina_noduri_izolate(M_adiacenta, nodes);
        verifica_graful_regular(M_adiacenta, nodes);
        determina_matricea_distantelor(M_adiacenta, nodes, M_dist);
        verifica_conexitate(M_adiacenta, nodes);


        fisier.close();
    }