#include <iostream>
#include <fstream>
#include <queue>
#include <vector>
#include <climits>

using namespace std;

#define MAX_NODES 100

int adj[MAX_NODES][MAX_NODES];
bool visited[MAX_NODES];
int inchidereTranzitiva[MAX_NODES][MAX_NODES];
int V;

void addEdge(int u, int v, bool directed = true) {
    adj[u][v] = 1;
    if (!directed) adj[v][u] = 1;
}

void BFS_Moore(int start) {
    vector<int> dist(V, INT_MAX);
    vector<int> parent(V, -1);
    queue<int> q;

    dist[start] = 0;
    q.push(start);

    while (!q.empty()) {
        int v = q.front();
        q.pop();
        for (int u = 0; u < V; u++) {
            if (adj[v][u] && dist[u] == INT_MAX) {
                dist[u] = dist[v] + 1;
                parent[u] = v;
                q.push(u);
            }
        }
    }

    cout << "Caile cele mai scurte de la nodul " << start << ":\n";
    for (int i = 0; i < V; i++) {
        cout << "Catre " << i << " (distanta: " << dist[i] << ") Carare: ";
        if (dist[i] == INT_MAX) {
            cout << "Nu exista cale";
        } else {
            vector<int> path;
            for (int at = i; at != -1; at = parent[at]) {
                path.push_back(at);
            }
            for (int j = path.size() - 1; j >= 0; j--) {
                cout << path[j] << " ";
            }
        }
        cout << endl;
    }
}

void BFS_Tree(int start) {
    vector<int> dist(V, -1);        // Vectorul de distanțe de la nodul sursă
    vector<int> parent(V, -1);      // Vectorul de părinți (pentru arborele descoperit)
    queue<int> q;

    dist[start] = 0;  // Distanta sursei față de sine este 0
    q.push(start);

    cout << "Arborele BFS (Nod: Distanta fata de " << start << "):\n";

    while (!q.empty()) {
        int v = q.front();
        q.pop();
        cout << v << ": " << dist[v] << ", Parinte: " << parent[v] << endl;

        // Parcurgem toți vecinii lui v
        for (int u = 0; u < V; u++) {
            if (adj[v][u] && dist[u] == -1) {  // Dacă există muchie și nodul nu a fost vizitat
                dist[u] = dist[v] + 1;  // Actualizăm distanța față de sursă
                parent[u] = v;          // Setăm părintele nodului u
                q.push(u);              // Adăugăm nodul u în coadă pentru a-l explora
            }
        }
    }
}


void afiseazaInchidereaTranzitiva() {
    for (int i = 0; i < V; i++) {
        for (int j = 0; j < V; j++) {
            inchidereTranzitiva[i][j] = adj[i][j];
        }
    }

    for (int i = 0; i < V; i++) {
        inchidereTranzitiva[i][i] = 1;
    }

    cout << "Inchiderea Tranzitiva:\n";
    for (int i = 0; i < V; i++) {
        for (int j = 0; j < V; j++) {
            cout << inchidereTranzitiva[i][j] << " ";
        }
        cout << endl;
    }
}


struct Position { int x, y; };

bool isValid(int x, int y, int rows, int cols, vector<vector<char>>& maze, vector<vector<bool>>& visited) {
    return x >= 0 && x < rows && y >= 0 && y < cols && maze[x][y] != '1' && !visited[x][y];
}

void solveMaze(string filename) {
    ifstream file(filename);
    if (!file) {
        cout << "Eroare la deschiderea fisierului labirintului!\n";
        return;
    }

    vector<vector<char>> maze;
    string line;
    Position start, end;
    int rows = 0, cols = 0;

    while (getline(file, line)) {
        if (cols == 0) cols = line.size();
        vector<char> row(line.begin(), line.end());
        maze.push_back(row);
        for (int j = 0; j < cols; j++) {
            if (row[j] == 'S') start = {rows, j};
            if (row[j] == 'F') end = {rows, j};
        }
        rows++;
    }
    file.close();

    vector<vector<bool>> visited(rows, vector<bool>(cols, false));
    vector<vector<Position>> parent(rows, vector<Position>(cols, {-1, -1}));
    queue<Position> q;

    q.push(start);
    visited[start.x][start.y] = true;

    int dx[] = {-1, 1, 0, 0};
    int dy[] = {0, 0, -1, 1};

    while (!q.empty()) {
        Position cur = q.front();
        q.pop();

        if (cur.x == end.x && cur.y == end.y) {
            cout << "Carare gasita în labirint:\n";
            vector<Position> path;
            for (Position at = end; at.x != -1; at = parent[at.x][at.y]) {
                path.push_back(at);
            }
            for (int i = path.size() - 1; i >= 0; i--) {
                cout << "(" << path[i].x << ", " << path[i].y << ") ";
            }
            cout << endl;
            return;
        }

        for (int i = 0; i < 4; i++) {
            int nx = cur.x + dx[i], ny = cur.y + dy[i];
            if (isValid(nx, ny, rows, cols, maze, visited)) {
                visited[nx][ny] = true;
                parent[nx][ny] = cur;
                q.push({nx, ny});
            }
        }
    }
    cout << "Nu s-a gasit nicio cale!\n";
}

void readGraph(const string& filename) {
    ifstream file(filename);
    if (!file) {
        cout << "Eroare la deschiderea fisierului labirintului!\n";
        return;
    }

    file >> V;

    int u, v;
    while (file >> u >> v) {
        addEdge(u, v);
    }

    file.close();
}

// Funcția DFS recursivă pentru a explora un arbore de la nodul v
void DFS_Visit(int v) {
    visited[v] = true;  // Marcăm nodul v ca vizitat
    cout << v << " ";    // Afișăm nodul descoperit

    // Parcurgem vecinii lui v
    for (int u = 0; u < V; u++) {
        if (adj[v][u] && !visited[u]) {  // Dacă există muchie și nodul nu a fost vizitat
            DFS_Visit(u);               // Apelăm recursiv pentru vecinul u
        }
    }
}

// Funcția DFS_Forest care explorează toate componentele conexe ale grafului
void DFS_Forest() {
    fill(visited, visited + V, false);  // Resetăm vectorul de vizite
    cout << "Padurea DFS:\n";

    // Pentru fiecare nod, dacă nu a fost vizitat, începem o căutare DFS
    for (int i = 0; i < V; i++) {
        if (!visited[i]) {
            cout << "Copacul radacina la " << i << ": ";
            DFS_Visit(i);  // Pornim un DFS pentru acest nod neexplorat
            cout << endl;
        }
    }
}

int main() {
    readGraph("graf.txt");

    int startNode;
    cout << "Introdu nodul de start: ";
    cin >> startNode;

    BFS_Moore(startNode);
    cout << "-----------------"<<endl;
    afiseazaInchidereaTranzitiva();
    cout << "-----------------"<<endl;
    BFS_Tree(startNode);
    cout << "-----------------"<<endl;
    DFS_Forest();
    cout << "-----------------"<<endl;
    cout << "Solutia labirintului...\n";
    solveMaze("labirint_1.txt");

    return 0;
}
