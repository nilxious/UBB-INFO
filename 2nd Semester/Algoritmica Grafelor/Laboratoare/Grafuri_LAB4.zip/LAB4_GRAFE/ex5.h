#ifndef EX5_H
#define EX5_H


int ex5();

#endif //EX5_H
