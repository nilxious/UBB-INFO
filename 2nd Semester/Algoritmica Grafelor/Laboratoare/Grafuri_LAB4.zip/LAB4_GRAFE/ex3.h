#ifndef EX3_H
#define EX3_H

int ex3();

#endif //EX3_H
