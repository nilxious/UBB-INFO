#ifndef EX4_H
#define EX4_H

int ex4();

#endif //EX4_H
