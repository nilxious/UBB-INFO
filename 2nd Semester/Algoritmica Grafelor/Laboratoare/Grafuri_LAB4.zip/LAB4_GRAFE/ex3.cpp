#include <iostream>
#include <fstream>
#include <vector>
#include <string>
#include <map>
#include <queue>
using namespace std;

class Node {
public:
    char ch;
    int freq;
    char minChar;
    Node* left, * right;

    Node(char c, int f) {
        ch = c;
        freq = f;
        minChar = c;
        left = nullptr;
        right = nullptr;
    }

    Node(Node* l, Node* r) {
        ch = '\0';
        freq = l->freq + r->freq;
        left = l;
        right = r;
        minChar = min(l->minChar, r->minChar); // enforce ASCII tie-breaking
    }
};

struct Compare {
    bool operator()(Node* a, Node* b) {
        if (a->freq != b->freq)
            return a->freq > b->freq;
        return a->minChar > b->minChar;
    }
};

void preOrder(Node* root, map<char, string>& codes, string curr) {
    if (!root) return;
    if (!root->left && !root->right) {
        codes[root->ch] = curr;
        return;
    }
    preOrder(root->left, codes, curr + "0");
    preOrder(root->right, codes, curr + "1");
}

map<char, string> huffman(map<char, int>& frecv) {
    priority_queue<Node*, vector<Node*>, Compare> pq;
    for (auto& [ch, freq] : frecv) {
        Node* tmp = new Node(ch, freq);
        pq.push(tmp);
    }

    while (pq.size() > 1) {
        Node* l = pq.top(); pq.pop();
        Node* r = pq.top(); pq.pop();

        Node* merged = new Node(l, r);
        pq.push(merged);
    }

    Node* root = pq.top();
    map<char, string> codes;
    preOrder(root, codes, "");
    return codes;
}

int ex3() {
    ifstream fin("input3.txt");
    ofstream fout("output3.txt");

    string text;
    getline(fin, text, '\0');

    map<char, int> frecv;
    for (char ch : text) frecv[ch]++;

    fout << frecv.size() << "\n";
    for (auto& [ch, f] : frecv)
        fout << ch << " " << f << "\n";

    map<char, string> codes = huffman(frecv);
    for (char ch : text)
        fout << codes[ch];
    fout << "\n";

    fin.close();
    fout.close();
    return 0;
}