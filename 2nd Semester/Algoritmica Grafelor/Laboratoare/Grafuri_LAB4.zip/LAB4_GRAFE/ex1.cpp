#include <iostream>
#include <fstream>
#include <vector>
#include <set>

using namespace std;

int ex1() {
    ifstream fin("input1.txt");
    ofstream fout("output1.txt");

    int N;
    fin >> N;
    vector<int> parent(N);
    vector<vector<int>> adj(N);
    vector<int> degree(N, 0);

    //construim arborele bi
    for (int i = 0; i < N; ++i) {
        fin >> parent[i];
        if (parent[i] != -1) { //skip root
            adj[i].push_back(parent[i]);
            adj[parent[i]].push_back(i);
            degree[i]++;
            degree[parent[i]]++;
        }
    }

    //frunza are gradul = 1
    set<int> leaves;
    for (int i = 0; i < N; ++i)
        if (degree[i] == 1)
            leaves.insert(i);

    vector<int> prufer;

    for (int step = 0; step < N - 2; ++step) {
        int leaf = *leaves.begin(); //dam remove la frunza minima
        leaves.erase(leaves.begin());

        for (int neighbor : adj[leaf]) {
            if (degree[neighbor] > 0) {
                prufer.push_back(neighbor);
                degree[neighbor]--;
                if (degree[neighbor] == 1)
                    leaves.insert(neighbor);
                break;
            }
        }

        degree[leaf] = 0;
    }

    fout << prufer.size() << "\n";
    for (int x : prufer)
        fout << x << " ";

    fin.close();
    fout.close();
    return 0;
}
