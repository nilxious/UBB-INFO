#ifndef EX1_H
#define EX1_H

int ex1();

#endif //EX1_H
