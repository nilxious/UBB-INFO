#include <iostream>
#include <fstream>
#include <vector>
#include <set>

using namespace std;

int ex2() {
    ifstream fin("input2.txt");
    ofstream fout("output2.txt");

    int M;
    fin >> M;

    vector<int> code(M);
    for (int i = 0; i < M; ++i)
        fin >> code[i];

    int N = M + 2;
    vector<int> degree(N, 1);
    for (int x : code)
        degree[x]++;

    set<int> leaves;
    for (int i = 0; i < N; ++i)
        if (degree[i] == 1)
            leaves.insert(i);

    vector<int> parent(N, -1);

    for (int x : code) {
        int leaf = *leaves.begin();
        leaves.erase(leaves.begin());
        parent[leaf] = x;

        if (--degree[x] == 1)
            leaves.insert(x);
    }

    // Conecteaza ultimele 2 noduri
    auto it = leaves.begin();
    int u = *it++;
    int v = *it;

    parent[u] = v;
    // Facem 0 radacina
    if (parent[0] != -1) {
        int real_root = 0;
        int old_parent = parent[0];
        parent[0] = -1;

        int curr = old_parent;
        while (parent[curr] != -1) {
            int temp = parent[curr];
            parent[curr] = real_root;
            real_root = curr;
            curr = temp;
        }
        parent[curr] = real_root;
    }

    fout << N << "\n";
    for (int i = 0; i < N; ++i)
        fout << parent[i] << " ";

    return 0;
}
