//
// Created by Catalin on 5/23/2025.
//

#ifndef EX2_H
#define EX2_H

int ex2();

#endif //EX2_H
