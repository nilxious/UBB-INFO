//
// Created by Catalin on 5/23/2025.
//
#include "ex1.h"
#include "ex2.h"
#include "ex3.h"
#include "ex4.h"
#include "ex5.h"

int main() {
    ex1();
    ex2();
    ex3();
    ex4();
    ex5();
}