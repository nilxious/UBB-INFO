#include <iostream>
#include <fstream>
#include <vector>
#include <algorithm>

using namespace std;

struct Edge {
    int x, y, w;
    bool operator<(const Edge& other) const {
        return w < other.w;
    }
};

vector<int> parent, rankSet;

int find(int x) {
    if (parent[x] != x)
        parent[x] = find(parent[x]);  // path compresson
    return parent[x];
}

bool unite(int a, int b) {
    a = find(a);
    b = find(b);
    if (a == b) return false;  // deja in acelasi set
    if (rankSet[a] < rankSet[b]) swap(a, b);
    parent[b] = a;
    if (rankSet[a] == rankSet[b]) rankSet[a]++;
    return true;
}

int ex5() {
    ifstream fin("input5.txt");
    ofstream fout("output5.txt");

    int V, E;
    fin >> V >> E;

    vector<Edge> edges(E);
    for (int i = 0; i < E; ++i) {
        fin >> edges[i].x >> edges[i].y >> edges[i].w;
    }

    sort(edges.begin(), edges.end());  // sortam dupa weight

    parent.resize(V);
    rankSet.resize(V, 0);
    for (int i = 0; i < V; ++i)
        parent[i] = i;

    int totalCost = 0;
    vector<pair<int, int>> mstEdges;

    for (const Edge& e : edges) {
        if (unite(e.x, e.y)) {
            totalCost += e.w;
            mstEdges.emplace_back(e.x, e.y);
        }
    }

    fout << totalCost << "\n";
    fout << mstEdges.size() << "\n";
    for (auto& [x, y] : mstEdges)
        fout << x << " " << y << "\n";

    fin.close();
    fout.close();
    return 0;
}