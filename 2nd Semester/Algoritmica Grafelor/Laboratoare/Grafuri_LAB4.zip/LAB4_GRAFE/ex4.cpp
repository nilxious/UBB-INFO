#include <iostream>
#include <fstream>
#include <map>
#include <queue>
#include <string>
using namespace std;

class Node {
public:
    char ch;
    int freq;
    char minChar;
    Node* left, * right;

    Node(char c, int f) {
        ch = c;
        freq = f;
        minChar = c;
        left = nullptr;
        right = nullptr;
    }

    Node(Node* l, Node* r) {
        ch = 0;
        freq = l->freq + r->freq;
        left = l;
        right = r;
        minChar = min(l->minChar, r->minChar);
    }
};

struct Compare {
    bool operator()(Node* a, Node* b) {
        if (a->freq != b->freq) return a->freq > b->freq;
        return a->minChar > b->minChar;
    }
};

Node* buildTree(map<char, int>& frecv) {
    priority_queue<Node*, vector<Node*>, Compare> pq;
    for (auto& [ch, f] : frecv)
        pq.push(new Node(ch, f));

    while (pq.size() > 1) {
        Node* left = pq.top(); pq.pop();
        Node* right = pq.top(); pq.pop();
        pq.push(new Node(left, right));
    }

    return pq.top(); // root
}

string decode(Node* root, const string& encoded) {
    string decoded;
    Node* curr = root;
    for (char bit : encoded) {
        if (bit == '0') curr = curr->left;
        else curr = curr->right;

        if (!curr->left && !curr->right) {
            decoded += curr->ch;
            curr = root;
        }
    }
    return decoded;
}

int ex4() {
    ifstream fin("input4.txt");
    ofstream fout("output4.txt");

    int N;
    fin >> N;
    map<char, int> frecv;
    for (int i = 0; i < N; ++i) {
        char ch;
        int f;
        fin >> ws >> ch >> f;
        frecv[ch] = f;
    }

    string encoded;
    fin >> encoded;

    Node* root = buildTree(frecv);
    string decoded = decode(root, encoded);

    fout << decoded << "\n";

    fin.close();
    fout.close();
    return 0;
}