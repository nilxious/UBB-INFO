//
// Created by Catalin on 5/25/2025.
//

#ifndef EX1SI2_H
#define EX1SI2_H


int ex1si2();



#endif //EX1SI2_H
