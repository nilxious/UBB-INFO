#include <iostream>
#include <fstream>
#include <vector>
#include <algorithm>
#include <queue>
const int INF = 1e9;
using namespace std;


struct Edge {
    int to, rev;
    int cap;
};

int V, E;
vector<vector<Edge>> adj;
vector<int> height, excess;

void addEdge(int u, int v, int c) {
    adj[u].push_back({ v, (int)adj[v].size(), c });
    adj[v].push_back({ u, (int)adj[u].size() - 1, 0 });
}

void push(int u, Edge& e) {
    int v = e.to;
    int flow = min(excess[u], e.cap);
    if (flow > 0 && height[u] == height[v] + 1) {
        e.cap -= flow;
        adj[v][e.rev].cap += flow;
        excess[u] -= flow;
        excess[v] += flow;
    }
}

void relabel(int u) {
    int minH = 2 * V;
    for (auto& e : adj[u]) {
        if (e.cap > 0)
            minH = min(minH, height[e.to]);
    }
    if (minH < 2 * V)
        height[u] = minH + 1;
}

void discharge(int u) {
    while (excess[u] > 0) {
        for (auto& e : adj[u]) {
            if (excess[u] == 0) break;
            push(u, e);
        }
        if (excess[u] > 0)
            relabel(u);
    }
}

int maxFlow(int source, int sink) {
    height.assign(V, 0);
    excess.assign(V, 0);
    height[source] = V;

    for (auto& e : adj[source]) {
        int flow = e.cap;
        e.cap = 0;
        adj[e.to][e.rev].cap += flow;
        excess[e.to] += flow;
    }

    queue<int> q;
    for (int i = 0; i < V; ++i) {
        if (i != source && i != sink && excess[i] > 0)
            q.push(i);
    }

    while (!q.empty()) {
        int u = q.front(); q.pop();
        int oldHeight = height[u];
        discharge(u);
        if (excess[u] > 0 && height[u] > oldHeight)
            q.push(u);
    }

    return excess[sink];
}

int bfs(int sursa, int dest, vector<vector<int>>& graf, vector<vector<int>>& capacity, vector<int>& parent){
    fill(parent.begin(), parent.end(), -1);
    parent[sursa] = -2;

    queue<pair<int, int>> q;
    q.push({ sursa, INF });

    while (!q.empty()) {
        int curr = q.front().first, flow = q.front().second;
        q.pop();

        for (int vecin : graf[curr]) {
            if (parent[vecin] == -1 && capacity[curr][vecin] > 0) {
                parent[vecin] = curr;
                int newFlow = min(flow, capacity[curr][vecin]);
                if (vecin == dest)
                    return newFlow;
                q.push({ vecin, newFlow });
            }
        }
    }
    return 0;
}

int edmonds_karp(int sursa, int dest, vector<vector<int>>& graf, vector<vector<int>>& capacity) {
    int flow = 0;
    int V = graf.size();
    vector<int> parent(V);

    while (1) {
        int newFlow = bfs(sursa, dest, graf, capacity, parent);
        if (newFlow == 0) break;

        flow += newFlow;
        int curr = dest;
        while (curr != sursa) {
            int prev = parent[curr];
            capacity[prev][curr] -= newFlow;
            capacity[curr][prev] += newFlow;

            curr = prev;
        }
    }
    return flow;
}

int ex1si2() {
    ifstream fin("input12.txt");
    ofstream fout("output12.txt");

    //int V, E;
    fin >> V >> E;
    adj.assign(V, vector<Edge>());

    vector<vector<int>> graf(V);
    vector<vector<int>> capacity(V, vector<int>(V));
    for (int i = 0; i < E; ++i) {
        int x, y, z;
        fin >> x >> y >> z;
        graf[x].push_back(y);
        graf[y].push_back(x);
        capacity[x][y] += z;

        addEdge(x, y, z);
    }

    int max_flow = edmonds_karp(0, V - 1, graf, capacity);
    fout << "Edmonds karp: "<<max_flow << "\n";

    max_flow = maxFlow(0, V - 1);
    fout << "Preflux: " << max_flow << "\n";

    fin.close();
    fout.close();
    return 0;
}
