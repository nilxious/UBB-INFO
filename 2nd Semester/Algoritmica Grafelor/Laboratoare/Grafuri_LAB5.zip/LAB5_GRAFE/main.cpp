#include <iostream>
#include "ex1si2.h"
#include "ex3.h"

int main()
{
    ex1si2();
    ex3();
    return 0;
}
