#include <iostream>
#include <fstream>
#include <vector>
#include <stack>
#include <algorithm>
using namespace std;

int Varf, Edge;
vector<vector<int>> adjacent;
vector<vector<bool>> used;
vector<int> result;

void dfs(int u) {
    stack<int> st;
    st.push(u);

    while (!st.empty()) {
        int v = st.top();
        bool found = false;

        //incercam sa gasim o muchie nevizitata
        for (int i = 0; i < adjacent[v].size(); ++i) {
            int to = adjacent[v][i];
            if (!used[v][i]) {
                used[v][i] = true;

                // mark reverse edge as used
                for (int j = 0; j < adjacent[to].size(); ++j) {
                    if (adjacent[to][j] == v && !used[to][j]) {
                        used[to][j] = true;
                        break;
                    }
                }

                st.push(to);
                found = true;
                break;
            }
        }

        if (!found) {
            result.push_back(v);
            st.pop();
        }
    }
}

int ex3() {
    ifstream fin("input3.txt");
    ofstream fout("output3.txt");

    fin >> Varf >> Edge;
    adjacent.assign(Varf, vector<int>());
    used.assign(Varf, vector<bool>());

    for (int i = 0; i < Edge; ++i) {
        int u, v;
        fin >> u >> v;
        adjacent[u].push_back(v);
        adjacent[v].push_back(u);
    }

    // resize used matrix
    for (int i = 0; i < Varf; ++i)
        used[i].resize(adjacent[i].size(), false);

    dfs(0);

    for (int x : result)
        fout << x << " ";
    fout << "\n";

    fin.close();
    fout.close();
    return 0;
}